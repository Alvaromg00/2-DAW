<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Álvaro Morón González">
    <title>arrays1</title>
</head>
<body>
    <?php
    function insert($tabla, $array, &$sentencia_sql){
        $claves=array_keys($array[0]);
        $valores=[];
        foreach ($array as $registro){
            $valoresRegistro=[];
            foreach ($claves as $clave){
                $valoresRegistro[]="'".$registro[$clave]."'";
            }
            $valores[]="(".implode(", ", $valoresRegistro).")";
        }

        $sentencia_sql=str_replace("tabla", $tabla, $sentencia_sql);
        $sentencia_sql=str_replace("campos", implode(', ', $claves), $sentencia_sql);
        $sentencia_sql=str_replace("valores", implode(', ', $valores), $sentencia_sql);
        return $sentencia_sql;

    }
    $datos=[
        ['dni'=>111, 'nombre'=>'Marta', 'apellidos'=>'García', 'edad'=>21, 'ciclo'=>'daw'],
        ['dni'=>222, 'nombre'=>'Lucia', 'apellidos'=>'Pérez', 'edad'=>18, 'ciclo'=>'daw'],
        ['dni'=>333, 'nombre'=>'Maya', 'apellidos'=>'Rodriguez', 'edad'=>22, 'ciclo'=>'daw'],
        ['dni'=>444, 'nombre'=>'Rita', 'apellidos'=>'Gutierrez', 'edad'=>25, 'ciclo'=>'daw']];

    $sentencia_sql="insert into tabla (campos) values (valores)";
    insert("Alumnos", $datos, $sentencia_sql);
   echo $sentencia_sql;

    ?>
</body>
</html>

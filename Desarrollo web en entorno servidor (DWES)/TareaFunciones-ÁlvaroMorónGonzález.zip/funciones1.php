<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Álvaro Morón González">
    <title>funciones1</title>
</head>
<body>
<?php
function insert($tabla, $array){
    $claves=array_keys($array[0]);
    $valores=[];
    foreach ($array as $registro){
        $valoresRegistro=[];
        foreach ($claves as $clave){
            $valoresRegistro[]="'".$registro[$clave]."'";
        }
        $valores[]="(".implode(", ", $valoresRegistro).")";
    }


    $cadena="INSERT INTO ".$tabla." (".implode(', ', $claves).") VALUES (".implode(', ', $valores);
    return $cadena;
}
$datos=[
    ['dni'=>111, 'nombre'=>'Marta', 'apellidos'=>'García', 'edad'=>21, 'ciclo'=>'daw'],
    ['dni'=>222, 'nombre'=>'Lucia', 'apellidos'=>'Pérez', 'edad'=>18, 'ciclo'=>'daw'],
    ['dni'=>333, 'nombre'=>'Maya', 'apellidos'=>'Rodriguez', 'edad'=>22, 'ciclo'=>'daw'],
    ['dni'=>444, 'nombre'=>'Rita', 'apellidos'=>'Gutierrez', 'edad'=>25, 'ciclo'=>'daw']];


$resultado = insert('Alumnos', $datos);
echo $resultado;


?>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Álvaro Morón González">
    <title>arrays1</title>
</head>
<body>
    <?php
    function operaciones($operacion, $simbolo, $num1, $num2){
        $resultado= $operacion($num1, $num2);
        echo $num1." ".$simbolo." ".$num2." = ".$resultado."<br>";
    }
    $suma= function ($num1, $num2){
        return $num1+$num2;
    };

    operaciones($suma, "+", 5, 3);

    $resta= function ($num1, $num2){
        return $num1-$num2;
    };
    operaciones($resta, "-", 5, 3);

    $multiplicacion= function ($num1, $num2){
        return $num1*$num2;
    };

    operaciones($multiplicacion, "*", 5, 3);

    $division= function ($num1, $num2){
        return $num1/$num2;
    };

    operaciones($division, "/", 5, 3);
    ?>
</body>
</html>
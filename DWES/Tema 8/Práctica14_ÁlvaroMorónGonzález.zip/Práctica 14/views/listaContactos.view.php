<?php
include_once __DIR__.'/../partials/barraNavegacion.php';
?>
<p>lista de contactos:</p>

<table>
    <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Teléfono</th>
        <th>Fecha de alta</th>
        <th>Acciones</th>
    </tr>
    <?php foreach ($contactos as $contacto): ?>
        <tr>
            <td><?php echo $contacto['id'];?></td>
            <td><?php echo $contacto['nombre']; ?></td>
            <td><?php echo $contacto['telefono']; ?></td>
            <td><?php echo $contacto['fecha_alta']; ?></td>
            <td>
                <form method="post" action="../app/editarContacto.php">
                    <input type="hidden" name="id_contacto" value="<?php echo $contacto['id']; ?>">
                    <button type="submit" id="editar">Editar</button>
                </form>
                <form method="post" action="../app/borrar.php" onsubmit="return confirm('¿Estás seguro de que deseas borrar este contacto?')">
                    <input type="hidden" name="id_contacto" value="<?php echo $contacto['id']; ?>">
                    <button type="submit" id="borrar">Borrar</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
</body>
</html>


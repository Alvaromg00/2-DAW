<?php
include_once __DIR__.'/../partials/barraNavegacion.php';
?>
<p>Agregar contacto:</p>

<form method="post" action="">
    <label for="id">ID:</label>
    <input type="text" name="id" value="<?php echo $nextId; ?>" size="3" disabled>
    <br><br>
    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" required>
    <br><br>

    <label for="telefono">Teléfono:</label>
    <input type="text" name="telefono" required>
    <br><br>

    <label for="fecha_alta">Fecha de alta:</label>
    <input type="date" name="fecha_alta" placeholder="00-00-0000" required>
    <br><br>

    <div>
        <input type="submit" value="Guardar" id="guardar">
        <a href="listaContactos.php"><button type="button" id="cancelar">Cancelar</button></a>
    </div>
</form>
</body>
</html>
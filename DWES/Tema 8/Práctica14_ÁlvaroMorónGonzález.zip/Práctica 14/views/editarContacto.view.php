<?php

include_once __DIR__.'/../partials/barraNavegacion.php';
?>

<p>Datos del contacto >> Editar datos</p>

<form method="post" action="../app/actualizarContacto.php">
    <input type="hidden" name="id_contacto" value="<?php echo $contacto['id']; ?>">
    <label>Nombre</label>
    <input type="text" name="nombre" value="<?php echo $contacto['nombre']; ?>">
    <br><br>
    <label>Teléfono</label>
    <input type="text" name="telefono" value="<?php echo $contacto['telefono']; ?>">
    <br><br>
    <label>Fecha de alta</label>
    <input type="date" name="fecha_alta" value="<?php echo $contacto['fecha_alta']; ?>">
    <br><br>
    <input type="submit" value="Actualizar" id="actualizar">
    <a href="listaContactos.php"><button type="button" id="cancelar">Cancelar</button></a>
</form>
</body>
</html>


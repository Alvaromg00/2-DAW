<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
    <div id="barra">
        <a href="listaContactos.php" class="opciones">Lista de empleados</a>
        <a href="agregarContacto.php" class="opciones">Agregar contacto</a>
    </div>


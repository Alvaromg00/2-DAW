<?php

require_once '../conexión/conection.class.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtén el ID del contacto a editar
    $id_contacto = $_POST["id_contacto"];

    // Obtén los datos actuales del contacto
    try {
        $conn = conection::make();
        $query = "SELECT * FROM Contactos WHERE id = :id_contacto";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id_contacto', $id_contacto);
        $stmt->execute();
        $contacto = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "Error al obtener los datos del contacto: " . $e->getMessage();
    }

}
require_once '../views/editarContacto.view.php';
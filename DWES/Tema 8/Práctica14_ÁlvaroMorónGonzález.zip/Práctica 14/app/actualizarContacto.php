<?php
require_once '../conexión/conection.class.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Procesa los datos del formulario
    $id_contacto = $_POST["id_contacto"];
    $nombre = $_POST["nombre"];
    $telefono = $_POST["telefono"];
    $fecha_alta = $_POST["fecha_alta"];

    // Actualiza los datos en la base de datos
    try {
        $conn = conection::make();
        $query = "UPDATE Contactos SET nombre = :nombre, telefono = :telefono, fecha_alta = :fecha_alta WHERE id = :id_contacto";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':telefono', $telefono);
        $stmt->bindParam(':fecha_alta', $fecha_alta);
        $stmt->bindParam(':id_contacto', $id_contacto);
        $stmt->execute();

        echo "Contacto actualizado exitosamente";
    } catch (PDOException $e) {
        echo "Error al actualizar el contacto: " . $e->getMessage();
    }
} else {
    echo "Solicitud no válida";
}
header("Location: listaContactos.php?id_contacto=$id_contacto");
exit();

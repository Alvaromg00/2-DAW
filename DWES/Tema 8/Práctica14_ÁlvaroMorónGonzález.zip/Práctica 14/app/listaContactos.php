<?php
require_once '../conexión/conection.class.php';

try {
    $conn = conection::make();

    $query = "SELECT * FROM Contactos";
    $stmt = $conn->query($query);

    // Obtiene los resultados como un array asociativo
    $contactos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error al recuperar los contactos: " . $e->getMessage();
}
require_once '../views/listaContactos.view.php';
?>

<?php
require_once '../conexión/conection.class.php';

try {
    $conn = conection::make();

    $query = "SHOW TABLE STATUS LIKE 'Contactos'";
    $stmt = $conn->query($query);
    $tableStatus = $stmt->fetch(PDO::FETCH_ASSOC);

    // Obtiene el próximo ID
    $nextId = $tableStatus['Auto_increment'];
} catch (PDOException $e) {
    echo "Error al obtener el próximo ID: " . $e->getMessage();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Procesa los datos del formulario
    $nombre = $_POST["nombre"];
    $telefono = $_POST["telefono"];
    $fecha_alta = $_POST["fecha_alta"];

    // Inserta datos en la base de datos
    try {
        $conn = conection::make();

        $query = "INSERT INTO Contactos (nombre, telefono, fecha_alta) VALUES ('$nombre', '$telefono', '$fecha_alta')";

        // Ejecuta la consulta
        $conn->exec($query);

        header("Location: listaContactos.php");
        exit();

    } catch (PDOException $e) {
        echo "Error al añadir el contacto";
    }
}

require_once '../views/agregarContacto.view.php';
?>

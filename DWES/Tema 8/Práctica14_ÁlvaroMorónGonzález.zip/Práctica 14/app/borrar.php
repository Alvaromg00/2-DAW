<?php
require_once '../conexión/conection.class.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtén el ID del contacto a eliminar
    $id_contacto = $_POST["id_contacto"];

    // Elimina el contacto de la base de datos
    try {
        $conn = conection::make();

        $query = "DELETE FROM Contactos WHERE id = :id_contacto";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id_contacto', $id_contacto);
        $stmt->execute();

        header("Location: listaContactos.php");
        exit();

    } catch (PDOException $e) {
        echo "Error al eliminar el contacto";
    }
}

?>
<?php

class conection
{
    public static function make(){
        $opciones=[
            PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES utf8",
            PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_PERSISTENT=>true
        ];
        try {
            $connection=new PDO('mysql:host=dwes.local;dbname=Agenda;charset=utf8', 'userProyecto', 'userProyecto', $opciones);
        }catch(PDOException $PDOException){
            die($PDOException->getMessage());
        }
        return $connection;
    }
}
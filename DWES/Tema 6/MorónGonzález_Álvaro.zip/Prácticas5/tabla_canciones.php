<?php
require 'canciones.inc.php';
$arrayCanciones=canciones();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Álvaro Morón González">
    <title>Tabla con canciones</title>
</head>
<body>
    <table border="1">
        <tr>
            <th>Título</th>
            <th>Album</th>
            <th>Género</th>
        </tr>
        <?php foreach ($arrayCanciones as $cancion) {
            echo "<tr>";
                echo "<td>" . $cancion["titulo"] . "</td>";
                echo "<td>" . $cancion["album"] . "</td>";
                echo "<td>" . $cancion["genero"] . "</td>";
                echo "</tr>";
     }?></table>
</body>
</html>
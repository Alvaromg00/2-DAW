<?php
function canciones() {
    $arrayCanciones = [
        ['titulo' => 'Cien gaviotas', 'album' => 'Canciones', 'genero' => 'Pop'],
        ['titulo' => 'Pero a tu lado', 'album' => 'Dos caras distintas', 'genero' => 'Pop'],
        ['titulo' => 'Happy', 'album' => 'GIRL', 'genero' => 'Pop'],
        ['titulo' => 'Devuelveme a mi chica', 'album' => 'Hombres G', 'genero' => 'Pop'],
        ['titulo' => 'Poker Face', 'album' => 'The Fame', 'genero' => 'Pop'],
        ['titulo' => 'Cross Road Blues', 'album' => 'Wheels of Fire', 'genero' => 'Blues'],
        ['titulo' => 'Spoonful', 'album' => 'Spoonful/Howlin', 'genero' => 'Blues'],
        ['titulo' => 'Lenny', 'album' => 'Texas Flood', 'genero' => 'Blues'],
        ['titulo' => 'Thunder Road', 'album' => 'Live/1975-85', 'genero' => 'Rock'],
        ['titulo' => 'Get back', 'album' => 'Let it Be', 'genero' => 'Rock'],
        ['titulo' => 'Gimme Shelter', 'album' => 'Gimme Shelter', 'genero' => 'Rock'],
        ['titulo' => 'I Love Paris', 'album' => 'Dont Go To Strangers', 'genero' => 'Jazz'],
        ['titulo' => 'Ramblin', 'album' => 'Soul 69', 'genero' => 'Jazz'],
    ];
    return $arrayCanciones;
}
?>

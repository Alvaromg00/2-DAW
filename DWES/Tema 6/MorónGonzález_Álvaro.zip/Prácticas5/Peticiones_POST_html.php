<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Álvaro Morón González">
    <title>Peticiones POST</title>
</head>
<body>
    <h1>Búsqueda de canciones</h1>
    <br>
    <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
        <label>Texto a buscar: </label>
        <input type="text" name="texto"><br><br>

        <label>Buscar en: </label>
        <input type="radio" name="busqueda" value="titulos">Títulos de canción
        <input type="radio" name="busqueda" value="albumes">Nombre de album
        <input type="radio" name="busqueda" value="ambos">Ambos campos<br><br>

        <label>Género musical: </label>
        <select name="generos" id="gnr">
            <option value="Todos">Todos</option>
            <option value="Rock">Rock</option>
            <option value="Blues">Blues</option>
            <option value="Jazz">Jazz</option>
            <option value="Pop">Pop</option>
        </select><br><br>
        <input type="submit" value="Buscar">
    </form><br>
    <a href="tabla_canciones.php">Tabla de canciones</a><br><br>
    <a href="generos_canciones.php">Géneros de canciones</a>
</body>
</html>
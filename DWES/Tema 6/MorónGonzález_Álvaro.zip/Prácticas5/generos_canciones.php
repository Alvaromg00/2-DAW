<?php
require 'canciones.inc.php';
$arrayCanciones=canciones();

$generos=array_column($arrayCanciones, 'genero');
$generos_unicos=array_unique($generos);
sort($generos_unicos);
echo "<b>"."Los géneros de las canciones son: "."</b><br><br>";
foreach ($generos_unicos as $genero){
    echo $genero."<br>";
}
?>

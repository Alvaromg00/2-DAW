<?php
require 'canciones.inc.php';
$arrayCanciones=canciones();
$arrayResultados=[];

if ($_SERVER['REQUEST_METHOD']==='POST'){
    $busqueda=trim(htmlspecialchars($_POST['texto']));
    $metodo=trim(htmlspecialchars($_POST['busqueda']));
    $genero=trim(htmlspecialchars($_POST['generos']));

    if (!empty($busqueda) && !empty($metodo)){
        $coincidencias=[];

        foreach ($arrayCanciones as $cancion){
            switch ($metodo){
                case "titulos":{
                    if ($genero!="Todos"){
                        if(strpos(strtolower($cancion['titulo']), strtolower($busqueda))!==false && strpos(($cancion['genero']), $genero)!==false){
                            $coincidencias[]=$cancion;
                        }
                    }else{
                    if(strpos(strtolower($cancion['titulo']), strtolower($busqueda))!==false){
                    $coincidencias[]=$cancion;
                    }}
                    break;
                }
                case "albumes":{
                    if ($genero!="Todos"){
                        if(strpos(strtolower($cancion['album']), strtolower($busqueda))!==false && strpos(($cancion['genero']), $genero)!==false){
                            $coincidencias[]=$cancion;
                        }
                    }else{

                    if(strpos(strtolower($cancion['album']), strtolower($busqueda))!==false){
                        $coincidencias[]=$cancion;
                    }}
                    break;
                }
                default:{
                    if ($genero!="Todos"){
                        if(strpos(strtolower($cancion['titulo']), strtolower($busqueda))!==false || strpos(strtolower($cancion['album']), strtolower($busqueda))!==false){
                            if (strpos(($cancion['genero']), $genero)!==false){
                                $coincidencias[]=$cancion;
                            }
                        }

                    }else{
                        if(strpos(strtolower($cancion['titulo']), strtolower($busqueda)) !==false|| strpos(strtolower($cancion['album']), strtolower($busqueda))!==false){
                                $coincidencias[]=$cancion;
                        }
                    }
                }
            }
        }
        if (!empty($coincidencias)) {
            echo "<h3>Resultados:</h3>";
            echo "<table border='1'>";
            echo "<tr><th>Título</th><th>Album</th><th>Género</th></tr>";
            foreach ($coincidencias as $coincidencia) {
                echo "<tr>";
                echo "<td>" . $coincidencia["titulo"] . "</td>";
                echo "<td>" . $coincidencia["album"] . "</td>";
                echo "<td>" . $coincidencia["genero"] . "</td>";
                echo "</tr>";
            } echo "</table>";
        }else{
            echo "No se encontraron coincidencias";
        }
    }else{
        echo "Faltan parámetros de búsqueda";
    }

}
require 'Peticiones_POST_html.php';
?>



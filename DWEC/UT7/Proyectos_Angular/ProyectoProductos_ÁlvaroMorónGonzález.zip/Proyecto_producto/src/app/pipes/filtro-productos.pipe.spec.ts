import { FiltroProductosPipe } from './filtro-productos.pipe';

describe('FiltroProductosPipe', () => {
  it('create an instance', () => {
    const pipe = new FiltroProductosPipe();
    expect(pipe).toBeTruthy();
  });
});

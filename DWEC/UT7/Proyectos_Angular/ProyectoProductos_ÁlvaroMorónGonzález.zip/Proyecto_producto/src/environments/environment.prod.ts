export const environment = {
    production: true,
    apiUrl: 'https://api.example.com',  // Ajusta la URL de la API de producción
  };
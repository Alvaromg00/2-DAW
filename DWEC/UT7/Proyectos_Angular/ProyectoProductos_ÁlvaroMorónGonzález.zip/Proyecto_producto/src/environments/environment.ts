export const environment = {
    production: false,
    apiUrl: 'http://localhost:4200/api',  // Ajusta la URL de la API según tu configuración
  };
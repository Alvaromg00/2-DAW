import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-FQPZQGSR.js";
import "./chunk-G6FUYGU2.js";
import "./chunk-BT2KMMFN.js";
import "./chunk-WL3RN7OX.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-QOFGU6D4.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
